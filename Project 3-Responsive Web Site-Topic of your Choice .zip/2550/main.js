function myFunction() {
  var x = document.getElementById('myTopnav');
  if (x.className === 'topnav') {
    x.className += ' responsive';
  } else {
    x.className = 'topnav';
  }
}

const themeToggle = document.querySelector('#theme-toggle');
const body = document.querySelector('body');

themeToggle.addEventListener('change', function () {
  if (this.checked) {
    // toggle on
    body.style.backgroundColor = '#333';
    body.style.color = '#fff';
  } else {
    // toggle off
    body.style.backgroundColor = '#f0f8ff';
    body.style.color = 'black';
  }
});
